/** @format */

// /** @format */
// const dbPool = require("../config/database");

// const getAllUsers = () => {
//   const getQuery = "SELECT * FROM users";
//   return dbPool.execute(getQuery);
// };

// module.exports = {
//   getAllUsers,
// };
